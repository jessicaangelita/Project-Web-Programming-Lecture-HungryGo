@extends('template')

@section('title', 'create menu')

@section('body')
<h1> halo</h1>
@endsection



<?php $__env->startSection('title', 'create menu'); ?>

<?php $__env->startSection('body'); ?>

<div class="card" style="width: 18rem;">
    <img src="<?php echo e(asset('/storage/menus/'.$menu->image)); ?>" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title"><?php echo e($menu->name); ?></h5>
      <p class="card-text"><?php echo e($menu->description); ?></p>
      <p class="card-text"><?php echo e($menu->price); ?></p>
      <p class="card-text">Quantity</p>
      <form action="<?php echo e(route('storecart', ['id'=>$menu->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="number" class="form-control" name="quantity">
        <button class="btn btn-primary mt-3" type="submit">Add to Cart</button>
      </form>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Dropbox\My PC (LAPTOP-HSGBAKIC)\Downloads\Project-Web-Programming-Lecture-HungryGo\Project-Web-Programming-Lecture-HungryGo\resources\views/menudetail.blade.php ENDPATH**/ ?>
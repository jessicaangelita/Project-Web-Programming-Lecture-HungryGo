

<?php $__env->startSection('title', 'create menu'); ?>

<?php $__env->startSection('body'); ?>
<h1> halo</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Dropbox\My PC (LAPTOP-HSGBAKIC)\Downloads\Project-Web-Programming-Lecture-HungryGo\Project-Web-Programming-Lecture-HungryGo\resources\views/order.blade.php ENDPATH**/ ?>
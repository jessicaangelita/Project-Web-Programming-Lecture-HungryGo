<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('body'); ?>

<p class="display-2 text-center mt-4">Cart</p>

<?php if($cartHeader!=null): ?>
<?php $__currentLoopData = $cartHeader->cartDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card mb-3 m-5">
    <div class="row g-0">
      <div class="col-md-4">
        <img src="<?php echo e(asset('storage/menus/'.$cartDetail->Menu->image)); ?>" class="img-fluid rounded-start" alt="...">
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title">Nama Item: <?php echo e($cartDetail->Menu->name); ?></h5>
          <p class="card-text">Quantity: <?php echo e($cartDetail->quantity); ?></p>
          <p class="card-text">Total harga: <?php echo e($cartDetail->quantity * $cartDetail->Menu->price); ?></p>
        </div>
      </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<form action="/checkout" method="POST">
    <?php echo csrf_field(); ?>
    <button class="btn btn-primary">Check Out</button>
</form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Dropbox\My PC (LAPTOP-HSGBAKIC)\Downloads\Project-Web-Programming-Lecture-HungryGo\Project-Web-Programming-Lecture-HungryGo\resources\views/cart.blade.php ENDPATH**/ ?>
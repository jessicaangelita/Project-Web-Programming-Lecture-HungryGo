<?php $__env->startSection('title', 'dashboard'); ?>

<?php $__env->startSection('body'); ?>
<div class="d-flex flex-column m-5">
    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3" style="max-width: 100vw;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="<?php echo e(asset('/storage/menus/'.$menu->image)); ?>" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($menu->name); ?></h5>
                        
                        <p class="card-text"><small class="text-muted"><?php echo e($menu->price); ?></small></p>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                            <a href="<?php echo e(route('showmenu', ['id'=> $menu->id])); ?>" class="btn btn-primary">Edit menu</a>
                            <?php else: ?>
                            <a href="<?php echo e(route('showmenu', ['id'=> $menu->id])); ?>" class="btn btn-primary">Add to cart</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Dropbox\My PC (LAPTOP-HSGBAKIC)\Downloads\Project-Web-Programming-Lecture-HungryGo\Project-Web-Programming-Lecture-HungryGo\resources\views/dashboard.blade.php ENDPATH**/ ?>